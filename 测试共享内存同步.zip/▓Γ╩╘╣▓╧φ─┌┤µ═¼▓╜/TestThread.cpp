#include "stdafx.h"
#include "TestThread.h"
#include <process.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CTestThread	g_tt;

CTestThread::CTestThread()
{
	m_sharemem.Create("mytest09");
}


CTestThread::~CTestThread()
{
}


void	CTestThread::ThreadRun(void* data)
{
	SInfo* info = (SInfo*)data;
	
	info->runStatus = 1;
	info->tid = GetCurrentThreadId();

	while (info->runStatus == 1)
	{
		info->countRun++;	

		if (g_tt.m_sharemem.SpinIslock(&g_tt.m_sharemem.m_dt->spinlock[0]))
			info->countIsLock++;

		g_tt.m_sharemem.SpinLock(&g_tt.m_sharemem.m_dt->spinlock[0]);

		g_tt.m_sharemem.m_dt->info.curThreadId = info->tid;
		Sleep(10);
		
		if (g_tt.m_sharemem.m_dt->info.curThreadId != info->tid)
			info->countError++;

		g_tt.m_sharemem.SpinUnlock(&g_tt.m_sharemem.m_dt->spinlock[0]);
		Sleep(1);
		//::SwapContex()
	}
	info->runStatus = 0;
}

CTestThread::VecInfos	CTestThread::AddThreads(int count)
{
	VecInfos v;

	for (int i = 0; i < count; i++)
	{
		SInfo* p = new SInfo;
		memset(p, 0, sizeof(SInfo));
		m_vec.push_back(p);
		v.push_back(p);
		_beginthread(CTestThread::ThreadRun, 0, p);
	}
	return v;
}
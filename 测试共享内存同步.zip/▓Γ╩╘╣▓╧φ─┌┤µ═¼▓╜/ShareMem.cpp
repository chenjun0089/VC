#include "stdafx.h"
#include "ShareMem.h"




#pragma once

#include <vector>
using namespace std;
#include "ShareMem.h"

class CTestThread
{
public:
	CTestThread();
	~CTestThread();

	struct SShareMem
	{
		DWORD	lock1;
		char	txt[32];
		DWORD	curThreadId;
		char	allPid[256];
	};



	struct SInfo
	{
		int		runStatus;	//0=û��ʼ 1=��ʼ�� 2=��ֹ
		DWORD	tid;
		int		countRun;
		int		countError;
		int		countIsLock;
	};

	CShareMem<SShareMem>	m_sharemem;

	typedef vector<SInfo*>	VecInfos;
	VecInfos	m_vec;

	static void	ThreadRun(void* data);

	VecInfos	AddThreads(int count);
};

extern CTestThread	g_tt;
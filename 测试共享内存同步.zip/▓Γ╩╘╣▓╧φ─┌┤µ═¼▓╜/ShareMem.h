#pragma once

template<class _MyDateType>
class CShareMem
{
public:

#pragma pack(1)
	struct SData
	{
		_MyDateType		info;

		volatile long	spinlock[10];
	};
#pragma pack() 

	HANDLE	m_hMapping;
	SData	*m_dt;

	CShareMem() {
		m_hMapping = NULL;
		m_dt = NULL;
	}
	~CShareMem()
	{
		Close();
	}

	bool	Create(const char* memname)
	{
		DWORD flProtect = PAGE_READWRITE;
		DWORD dwLength = sizeof(SData);

		m_hMapping = ::CreateFileMappingA((HANDLE)0xFFFFFFFF, NULL, flProtect, 0, dwLength, memname);
		if (m_hMapping == NULL)
			return false;

		DWORD hr = GetLastError(); //����183,˵�����ڴ��Ѿ�����

		DWORD dwDesiredAccess = FILE_MAP_WRITE | FILE_MAP_READ;
		m_dt = (SData*)MapViewOfFile(m_hMapping, dwDesiredAccess, 0, 0, 0);

		return true;
	}

	void	Close()
	{
		if (m_dt != NULL)
		{
			FlushViewOfFile(m_dt, 0);
			UnmapViewOfFile(m_dt);
			m_dt = NULL;
		}
		if (m_hMapping != NULL)
		{
			CloseHandle(m_hMapping);
			m_hMapping = NULL;
		}
	}


	void	SpinLock(volatile long* v)
	{
		for (; 0 != InterlockedExchange(v, 1);)
		{
			Sleep(1);
		}
	}
	void	SpinUnlock(volatile long* v)
	{
		InterlockedExchange(v, 0);
	}
	int		SpinTrylock(volatile long* lock)
	{
		return !InterlockedExchange(lock, 1);
	}
	int		SpinIslock(volatile long* lock)
	{
		return InterlockedExchangeAdd(lock, 0);
	}

};

